CMAKE_CONFIG_TYPE
-----------------

.. include:: ENV_VAR.txt

The default build configuration for :ref:`Build Tool Mode` and
``ctest`` build handler when there is no explicit configuration given.
